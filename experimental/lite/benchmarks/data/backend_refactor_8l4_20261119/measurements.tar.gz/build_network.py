import os,subprocess,time
from pathlib import Path
root=Path.cwd()
base=root/'build/backend_refactor_20261119'
while not (base/'performance/summary.json').exists():
    log=(base/'performance-driver.log').read_text()
    if 'Traceback' in log or 'did not finish successfully' in log:
        raise SystemExit('Performance comparison failed; inspect before building.')
    time.sleep(5)
cmake=str(base/'tools/cmake/data/bin/cmake')
source=base/'deps/mscclpp'
build=base/'deps/mscclpp-build'
commands=[
 [cmake,'-S',str(source),'-B',str(build),'-DCMAKE_BUILD_TYPE=Release',
  '-DMSCCLPP_USE_CUDA=ON','-DMSCCLPP_GPU_ARCHS=89','-DCMAKE_CUDA_ARCHITECTURES=89',
  '-DCMAKE_CUDA_COMPILER=/usr/local/cuda-12.9/bin/nvcc','-DCUDAToolkit_ROOT=/usr/local/cuda-12.9',
  '-DMSCCLPP_BUILD_PYTHON_BINDINGS=OFF','-DMSCCLPP_BUILD_EXT_NCCL=OFF',
  '-DMSCCLPP_BUILD_EXT_COLLECTIVES=OFF','-DMSCCLPP_BUILD_TESTS=OFF',
  '-DMSCCLPP_USE_GDRCOPY=OFF','-DMSCCLPP_BYPASS_GPU_CHECK=ON'],
 [cmake,'--build',str(build),'-j4'],
 ['make','-j4','nccl-multinode',
  str((base/'candidate/nccl_lite/network_sizes_check').relative_to(root)),
  str((base/'candidate/nccl_lite/network_queue_check').relative_to(root)),
  str((base/'candidate/uccl_lite_multinode_allreduce').relative_to(root)),
  'BUILD='+str((base/'candidate').relative_to(root)), 'CUDA_HOME=/usr/local/cuda-12.9',
  'NCCL_HOME=build/nccl-2.28.9','MSCCLPP_HOME='+str(source),'MSCCLPP_IB_BUILD='+str(build)],
]
for command in commands:
    print('Running:',command,flush=True)
    subprocess.run(command,check=True)
(base/'network-build-passed').write_text('Full network backend, common frontend, size/queue clients and standalone harness compiled.\n')
