import fcntl,json,subprocess,time
from pathlib import Path
root=Path.cwd()
base=root/'build/backend_refactor_20261119'
while not (base/'performance/summary.json').exists():
    if 'Traceback' in (base/'performance-driver.log').read_text():
        raise SystemExit('Performance failed; inspect before running checks.')
    time.sleep(3)
lock=open('/tmp/uccl-lite-integration-wxz-l4.lock','a')
fcntl.flock(lock,fcntl.LOCK_EX)
if subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip():
    raise SystemExit('GPU occupied before core checks')
folder=base/'core'
folder.mkdir(exist_ok=True)
names=['router_policy_check','dispatcher_check','dispatcher_cuda_check','router_check','router_graph_check']
command=['make','-j4',*[str((folder/('uccl_lite_'+name)).relative_to(root)) for name in names],
         'BUILD='+str(folder.relative_to(root)),'CUDA_HOME=/usr/local/cuda-12.9',
         'NCCL_HOME=build/nccl-2.28.9','CUTLASS_HOME=/data/zhongjie/cutlass-v4.5.0']
with (folder/'build.log').open('w') as log:subprocess.run(command,check=True,stdout=log,stderr=subprocess.STDOUT)
commands=[('policy',[str(folder/'uccl_lite_router_policy_check')]),
          ('dispatcher',[str(folder/'uccl_lite_dispatcher_check')]),
          ('dispatcher_cuda',[str(folder/'uccl_lite_dispatcher_cuda_check')])]
for devices in ['0,1,4,5','0,1,2,3,4,5,6,7']:
    n=len(devices.split(','))
    commands += [(f'eager{n}',[str(folder/'uccl_lite_router_check'),'--devices',devices]),
                 (f'graph{n}',[str(folder/'uccl_lite_router_graph_check'),'--devices',devices,'--gpu-progress'])]
results=[]
for name,cmd in commands:
    print('Running',name,flush=True)
    with (folder/(name+'.log')).open('w') as log:
        result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    results.append(dict(name=name,command=cmd,returncode=result.returncode))
    (folder/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    result.check_returncode()
print('All policy/dispatcher and four/eight-GPU eager/graph core checks passed.',flush=True)
